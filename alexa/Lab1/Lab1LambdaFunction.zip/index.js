'use strict';


/* ------------ Helpers that build all of the responses --------------------- */

function buildSpeechletResponse(title, output, repromptText, shouldEndSession)
{
var response =     {
        outputSpeech : {
            type : 'PlainText',
            text : output,
            ssml: "<speak> " + output + " </speak>"
        },
        card :{
            type : 'Simple',
            title : `23076 IoT7 `,
            content : output,
        },
        reprompt :{
            outputSpeech :
            {
                type : 'PlainText',
                text : repromptText,
            },
        },
        shouldEndSession,
    };
;
    return response;

}

function buildResponse(sessionAttributes, speechletResponse)
{
var response =     {
        version:
        '1.0',
        sessionAttributes,
        response : speechletResponse,
    };
    return response;


}

/* ---------- end: Helpers that build all of the responses ------------------ */

/* ----------- Functions that control the skill's behavior ------------------ */

function getWelcomeResponse(callback)
{

    // If we wanted to initialize the session to have some attributes we could add those here.
    const sessionAttributes = {Session:"New session"};
    const cardTitle = 'Welcome';
    const speechOutput = 'Welcome to Microchip US Masters 2019 Alexa class.  Ask me what is the secret key. ';

    // If the user either does not reply to the welcome message or says something that is not understood, they will be prompted again with this text.
    const repromptText = 'Please ask me the secret key';
    const shouldEndSession = false;

    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

getHelpResponse
function getHelpResponse(callback)
{

    // If we wanted to initialize the session to have some attributes we could add those here.
    const sessionAttributes = {};
    const cardTitle = 'Help';
    const speechOutput = 'The option is.  Ask me what is the secret key. ';

    // If the user either does not reply to the welcome message or says something that is not understood, they will be prompted again with this text.
    const repromptText = 'Ask me what is the secret key. ';
    const shouldEndSession = false;

    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}


/* ----------------------------- Events ------------------------------------- */

/**
 * Called when the user launches the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback)
{

    console.log(``);

    // Dispatch to your skill's launch.
    console.log("Calling getWelcomeResponse");

    getWelcomeResponse(callback);

}

function handleSessionEndRequest(callback) {

    const cardTitle = 'Session Ended';
    const speechOutput = 'Thank you for using Microchip Sensor board demo. Have a nice day!';
    // Setting this to true ends the session and exits the skill.
    const shouldEndSession = true;

    callback({}, buildSpeechletResponse(cardTitle, speechOutput, null, shouldEndSession));

}
/**
 * Called when the user specifies an intent for this skill.
 */
function getSecretKey(callback) {

    const cardTitle = 'Secret key';
    const speechOutput = 'The secret key is, masters. Tell me, the secret key and I will tell you the secret message. ' +
                        'But try telling me a wrong key to see what I answer. ';
    // Setting this to true ends the session and exits the skill.
    const shouldEndSession = false;

    callback({}, buildSpeechletResponse(cardTitle, speechOutput, speechOutput, shouldEndSession));

}
function getSecretMessage(callback,intentSlot) {

    const cardTitle = 'Secret Message';
    var speechOutput = "";
    var shouldEndSession = true;
    if (intentSlot.key.value == "masters")
    {
        shouldEndSession = true;
        speechOutput = 'Congratulation,  the secret message is:  "You have successfuly completed lab one. Good bye!';
    }else
    {
        shouldEndSession = false;
        speechOutput = 'Sorry, '+ intentSlot.key.value +' is not the secret key. Try again!';
    }

    // Setting this to true ends the session and exits the skill.


    callback({}, buildSpeechletResponse(cardTitle, speechOutput, null, shouldEndSession));

}

function onIntent(intentRequest, session, callback)
{

    console.log("");

    const intent = intentRequest.intent;
    const intentName = intentRequest.intent.name;
    const intentSlot = intentRequest.intent.slots;

    console.log("inIntent =>",intentName);
    // Dispatch to your skill's intent handlers

    if (intentName === 'secretKey')
    {
        getSecretKey(callback);
    }
    else if (intentName === 'secretMessage')
    {
        getSecretMessage(callback,intentSlot);
    }
    else if (intentName === 'AMAZON.HelpIntent') {
        getHelpResponse(callback);

    }
    else if (intentName === 'AMAZON.StopIntent' || intentName === 'AMAZON.CancelIntent') {
        handleSessionEndRequest(callback);

    } else if(intentName === 'closeSession')
    {
        handleSessionEndRequest(callback);
    }
    else {throw new Error('Invalid intent');}
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session)
{

    console.log(`onSessionEnded requestId = ${sessionEndedRequest.requestId}, sessionId = ${session.sessionId}
    `);
    // Add cleanup logic here

}

/* --------------------------- end: Events ---------------------------------- */


/* -------------------------- Main handler ---------------------------------- */

// Route the incoming request based on type (LaunchRequest, IntentRequest, etc.) The JSON body of the request is provided in the event parameter.
exports.handler = (event, context, callback) =>
{

    try{

        console.log("\rStarting handler =>\r");
        //return;
        console.log("Events", JSON.stringify(event));
        console.log("Context", JSON.stringify(context));
        console.log("callback", JSON.stringify(callback));


        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */
        /*
        if (event.session.application.applicationId !== 'amzn1.echo-sdk-ams.app.[unique-value-here]') {
             callback('Invalid Application ID');l
        }
         */

        if (event.request.type == 'LaunchRequest')
        {
            onLaunch(event.request,
                    event.session,
                    (sessionAttributes, speechletResponse) =>{
                        console.log("Returning from onLaunch");
                        context.succeed(buildResponse(sessionAttributes, speechletResponse));
            });
        } else if (event.request.type == 'IntentRequest')
        {
            onIntent(event.request,
                    event.session,
                    (sessionAttributes, speechletResponse) =>{
                        console.log("Returning from onIntent");
                        console.log("buildResponse returns =>",JSON.stringify( buildResponse(sessionAttributes, speechletResponse)));

                        context.succeed(buildResponse(sessionAttributes, speechletResponse));

                        console.log("Returning from callback");

            });
        } else if (event.request.type == 'SessionEndedRequest')
        {
            onSessionEnded(event.request, event.session);
            callback();
        }


    }

    catch(err)
    {
        callback(err);
    }

};

/* ----------------------- end: Main handler -------------------------------- */
