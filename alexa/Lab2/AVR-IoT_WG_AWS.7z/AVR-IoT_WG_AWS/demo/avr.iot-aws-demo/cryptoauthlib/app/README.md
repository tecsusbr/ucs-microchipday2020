app directory - Purpose
===================

This directory is for application specific implementation of various use cases.

Methods in this directory provide a simple API to perform potentially complex 
combinations of calls to the main atca crypto library or API.

