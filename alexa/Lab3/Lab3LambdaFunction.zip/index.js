'use strict';

/* ----------------------- IoT Configuration -------------------------------- */

var config = {};

config.IOT_BROKER_ENDPOINT = "xxxxxxxxxxxxxx-ats.iot.us-east-1.amazonaws.com".toLowerCase();
config.IOT_BROKER_REGION = "us-east-1";
config.IOT_THING_NAME = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";  //Entre no AWS IoT para confirmar o ID do seu dispositvo

// Load AWS SDK libraries
var AWS = require('aws-sdk');

AWS.config.region = config.IOT_BROKER_REGION;

// Initialize client for IoT
var iotData = new AWS.IotData({endpoint : config.IOT_BROKER_ENDPOINT});

/* -------------------- end: IoT Configuration ------------------------------ */

/* ------------ Helpers that build all of the responses --------------------- */

function buildSpeechletResponse(title, output, repromptText, shouldEndSession)
{
var response =     {
        outputSpeech : {
            type : 'PlainText',
            text : output,
            ssml: "<speak> " + output + " </speak>"
        },
        card :{
            type : 'Simple',
            title : `Sensor Board`,
            content : output,
        },
        reprompt :{
            outputSpeech :
            {
                type : 'PlainText',
                text : repromptText,
            },
        },
        shouldEndSession,
    };
;
    return response;

}

function buildResponse(sessionAttributes, speechletResponse)
{
var response =     {
        version:
        '1.0',
        sessionAttributes,
        response : speechletResponse,
    };
    return response;


}

/* ---------- end: Helpers that build all of the responses ------------------ */

/* ----------- Functions that control the skill's behavior ------------------ */

function getWelcomeResponse(callback)
{

    // If we wanted to initialize the session to have some attributes we could add those here.
    const sessionAttributes = {Session:"New session"};
    const cardTitle = 'Bem vindo ao Microchip Day Caxias do Sul';
    const speechOutput = 'Bem vindo ao Microchip Day Caxias do Sul. Obrigado a universidade, Future e Artimar pela oportunidade ';

    // If the user either does not reply to the welcome message or says something that is not understood, they will be prompted again with this text.
    const repromptText = 'Fale o que deseja fazer, como acender ou apagar a luz ou verificar como estão os sensores de temperatura e luminosidade';
    const shouldEndSession = false;

    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}



function getHelpResponse(callback)
{

    // If we wanted to initialize the session to have some attributes we could add those here.
    const sessionAttributes = {};
    const cardTitle = 'Tutorial';
    const speechOutput = 'É possível controlar a placa de sensores utilizando os comandos da Alexa. ' +
                            ' fale: ' + ' ligar ou desligar LED para controlá-lo. ' +
                            ' fale: ' + ' Qual a temperatura ou qual a luminosidade para receber os dados de temperatura '+'ou umidade. ';
    // If the user either does not reply to the welcome message or says something that is not understood, they will be prompted again with this text.
    const repromptText = 'Por favor, me diga o comando que deseja';
    const shouldEndSession = false;

    callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}


function createFavoriteLEDStatusAttributes(desiredLEDStatus)
{
 var response =     {
        desiredLEDStatus,
    };

    return response;


}

/**
 * Sets the LED state
 */
function setLEDState(intent, session, callback)
{

    const cardTitle = intent.name;
    const desiredLEDStateSlot = intent.slots.lightState;
    let shadowLED = 0;
    let repromptText = 'Diga outro comando';
    let sessionAttributes = {};

    const shouldEndSession = false;
    let speechOutput = '';


    if (desiredLEDStateSlot)
    {

        const desiredLEDState = desiredLEDStateSlot.value;
        sessionAttributes = createFavoriteLEDStatusAttributes(desiredLEDState);
        if ((desiredLEDState == 'branco')||(desiredLEDState == 'ligado')||(desiredLEDState == 'ligar')||(desiredLEDState == 'aceso')||(desiredLEDState == 'acender'))
        {
            shadowLED = 1;
            speechOutput = "O LED está ligado";

        }else
        if ((desiredLEDState == 'desligado')||(desiredLEDState == 'desligar')||(desiredLEDState == 'apagado')||(desiredLEDState == 'apagar'))
        {
            shadowLED = 0;
            speechOutput = "O LED está apagado" ;

        }else
        {
            speechOutput = "Eu não entendi o que você quer. Poderia tentar novamente?";
            repromptText = "Diga o comando novamente";
            callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
            return;
        }

        /*
         * Update AWS IoT
         */

        console.log("Alexa will say =>",speechOutput);
        var payloadObj = {"state" :
            { "desired" :
                { "D" : shadowLED
                }}};

        //Prepare the parameters of the update call
        var paramsUpdate = {

            "thingName" : config.IOT_THING_NAME,
            "payload" : JSON.stringify(payloadObj)

        };

        // Update IoT Device Shadow
        console.log("AWS-IOT => ",paramsUpdate);

        iotData.updateThingShadow(paramsUpdate, function(err, data)
        {

            if (err)
            {
                console.log(err); // Handle any errors
            } else
            {
                console.log("UpdateThingShadow=>",data);
                console.log("Calling callback from updateThingShadow returns");

                callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
                //context.succeed(buildResponse(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession)));

                console.log("buildSpeechletResponse returns =>",JSON.stringify(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession)));
                console.log("returning from callback from updateThingShadow returns");

            }

        });


    } else
    {

        speechOutput = "Eu não entendi o que você quer. Poderia tentar novamente?";
        repromptText = "Diga o comando novamente";

    }

    //callback(sessionAttributes, buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}


function getSensorStatusFromShadow(intent, session, callback) {

    let desiredLEDStatus;
    const repromptText = 'Diga outro comando';
    const sessionAttributes = {};
    let shouldEndSession = false;
    let speechOutput = '';



    //Prepare the parameters of the update call
    var paramsUpdate = {
        "thingName" : config.IOT_THING_NAME,
        //"payload" : JSON.stringify(payloadObj)
    };

    iotData.getThingShadow(paramsUpdate, function(err, data)
        {

            if (err)
            {
                console.log(err); // Handle any errors
            } else
            {
                console.log(data);
                var shadow = JSON.parse(data.payload);
                console.log("Temperature value is =>",shadow.state.reported.T);
                console.log("Light value is =>",shadow.state.reported.L);
                console.log("LED state is =>",shadow.state.reported.D);
                var LED = shadow.state.reported.D;

                if (intent.slots.sensorType.value == "temperatura")
                {
                    speechOutput = 'A temperatura é  '+ shadow.state.reported.T;
                }else
                if (intent.slots.sensorType.value == "luminosidade")
                {
                    speechOutput = 'A luminosidade está em '+ shadow.state.reported.L + " por cento";
                }else
                if(intent.slots.sensorType.value == "led")
                {
                    if (LED == 0)
                       speechOutput = 'O LED está desligado';
                     else
                        speechOutput = 'O LED está ligado';
                }else
                    speechOutput = 'Me pergunte, qual a temperatura ou umidade';

                //shouldEndSession = true;
                callback(sessionAttributes, buildSpeechletResponse(intent.name, speechOutput, repromptText, shouldEndSession));

            }

        });


    // Setting repromptText to null signifies that we do not want to reprompt the user.
    // If the user does not respond or says something that is not understood, the session
    // will end.
    //callback(sessionAttributes, buildSpeechletResponse(intent.name, speechOutput, repromptText, shouldEndSession));

}

/* --------- end: Functions that control the skill's behavior --------------- */


/* ----------------------------- Events ------------------------------------- */

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session)
{
    console.log(`onSessionStarted requestId = ${sessionStartedRequest.requestId}, sessionId = ${session.sessionId}
    `);
}

/**
 * Called when the user launches the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback)
{

    console.log(`onLaunch requestId = ${launchRequest.requestId}, sessionId = ${session.sessionId}
    `);

    // Dispatch to your skill's launch.
    console.log("Calling getWelcomeResponse");

    getWelcomeResponse(callback);

}

function handleSessionEndRequest(callback) {

    const cardTitle = 'Fim do Treinamento';
    const speechOutput = 'Obriado por participar do Mirochip MASTERs Brasil, Até o ano que vem!';
    // Setting this to true ends the session and exits the skill.
    const shouldEndSession = true;

    callback({}, buildSpeechletResponse(cardTitle, speechOutput, null, shouldEndSession));

}
/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback)
{

    console.log(`onIntent requestId = ${intentRequest.requestId}, sessionId = ${session.sessionId}
    `);

    const intent = intentRequest.intent;
    const intentName = intentRequest.intent.name;

    console.log("inIntent =>",intentName);
    // Dispatch to your skill's intent handlers
    // Dispatch to your skill's intent handlers

    if (intentName === 'LEDChange') {
        setLEDState(intent, session, callback);

    }
    else if (intentName === 'getSensorStatus') {
        getSensorStatusFromShadow(intent, session, callback);

    }
    else if (intentName === 'AMAZON.HelpIntent') {
        getHelpResponse(callback);

    }
    else if (intentName === 'AMAZON.StopIntent' || intentName === 'AMAZON.CancelIntent') {
        handleSessionEndRequest(callback);

    } else if(intentName === 'closeSession')
    {
        handleSessionEndRequest(callback);
    }
    else
    {
        //throw new Error('Invalid intent');
        const cardTitle = '';
        const speechOutput = 'Não consegui entender o que você quer. Poderia repetir!';
        // Setting this to true ends the session and exits the skill.
        const shouldEndSession = false;

        callback({}, buildSpeechletResponse(cardTitle, speechOutput, null, shouldEndSession));

    }
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session,callback)
{
    handleSessionEndRequest(callback);
    
    console.log(`onSessionEnded requestId = ${sessionEndedRequest.requestId}, sessionId = ${session.sessionId}
    `);
    // Add cleanup logic here

}

/* --------------------------- end: Events ---------------------------------- */


/* -------------------------- Main handler ---------------------------------- */

// Route the incoming request based on type (LaunchRequest, IntentRequest, etc.) The JSON body of the request is provided in the event parameter.
exports.handler = (event, context, callback) =>
{

    try{

        console.log("\rStarting handler =>\r");
        //return;
        console.log("Events", JSON.stringify(event));
        console.log("Context", JSON.stringify(context));
        console.log("callback", JSON.stringify(callback));


        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */
        /*
        if (event.session.application.applicationId !== 'amzn1.echo-sdk-ams.app.[unique-value-here]') {
             callback('Invalid Application ID');l
        }
         */

        if (event.request.type == 'LaunchRequest')
        {
            onLaunch(event.request,
                    event.session,
                    (sessionAttributes, speechletResponse) =>{
                        console.log("Returning from onLaunch");
                        //callback(null, buildResponse(sessionAttributes, speechletResponse));
                        context.succeed(buildResponse(sessionAttributes, speechletResponse));
            });
        } else if (event.request.type == 'IntentRequest')
        {
            onIntent(event.request,
                    event.session,
                    (sessionAttributes, speechletResponse) =>{
                        console.log("Returning from onIntent");
                        console.log("buildResponse returns =>",JSON.stringify(buildResponse(sessionAttributes, speechletResponse)));

                        //callback(null, buildResponse(sessionAttributes, speechletResponse));
                        context.succeed(buildResponse(sessionAttributes, speechletResponse));

                        console.log("Returning from callback");

            });
        } else if (event.request.type == 'SessionEndedRequest')
        {
            onSessionEnded(event.request,
                           event.session,
                           (sessionAttributes, speechletResponse) =>{
                           console.log("Returning from EndedRequest");
                           //callback(null, buildResponse(sessionAttributes, speechletResponse));
                           context.succeed(buildResponse(sessionAttributes, speechletResponse));
            });
           callback();
        }


    }

    catch(err)
    {
        callback(err);
    }

};

/* ----------------------- end: Main handler -------------------------------- */
